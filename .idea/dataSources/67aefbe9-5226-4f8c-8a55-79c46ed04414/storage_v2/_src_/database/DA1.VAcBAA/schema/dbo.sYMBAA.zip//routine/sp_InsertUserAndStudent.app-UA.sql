CREATE PROCEDURE sp_InsertUserAndStudent
    @UserName   NVARCHAR(100),
    @Fullname   NVARCHAR(255),
    @Password   NVARCHAR(255),
    @Photo      NVARCHAR(255),
    @Role       INT,
    @IsActive   BIT,
    @BirthDate  DATE,
    @Gmail      NVARCHAR(255),
    @ClassName  NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @User_ID INT;

    INSERT INTO Users(UserName, Fullname, PassWord, Photo, Role, IsActive)
    VALUES (
               @UserName,
               @Fullname,
               @Password,
               @Photo,
               @Role,
               @IsActive
           );

    -- Lấy ID vừa insert
    SET @User_ID = SCOPE_IDENTITY();

    INSERT INTO Students(User_ID, Fullname, BirthDate, Gmail, Classes)
    VALUES (
               @User_ID,
               @Fullname,
               @BirthDate,
               @Gmail,
               @ClassName
           );
END;
go

